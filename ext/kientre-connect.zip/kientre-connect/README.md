# Kiến Trẻ Connect

Tiện ích Chrome nối **kientre.click** với ứng dụng **Kiến Trẻ** trong Kiến Chuyên môn. Có tiện ích thì không phải dán cookie tay nữa.

- Tiện ích đọc cookie đăng nhập kientre.click của Chrome, kể cả cookie httpOnly. Việc này cần quyền `cookies` và quyền host `https://kientre.click/*`.
- Tiện ích gửi cookie tới đúng link `/exec` ghi trong mã kết nối, qua lệnh `ktExtPush`. Máy chủ kiểm phiên rồi lưu, giống hệt khi dán tay.
- Tiện ích tự gửi khi cài, khi mở Chrome, khi phiên đổi (đăng nhập lại, đổi tài khoản), 6 giờ một lần, và khi bấm **Gửi ngay**.
- Mã kết nối lấy ở **Kiến Trẻ › Kết nối › Lấy mã cho tiện ích**. Mỗi người một mã cho phiên nhận xét; quản lý có thêm một mã cho phiên giáo vụ.
- Mã cũ hết hiệu lực khi lấy mã mới hoặc khi bấm **Ngắt**.

## Cài đặt

1. Tải `https://kientre-internal.click/ext/kientre-connect.zip` rồi giải nén.
2. Mở `chrome://extensions` và bật **Chế độ dành cho nhà phát triển**.
3. Bấm **Tải tiện ích đã giải nén**, chọn thư mục `kientre-connect`.
4. Bấm biểu tượng tiện ích, dán mã kết nối, rồi bấm **Lưu mã**.

Tệp: `manifest.json` (MV3), `background.js` (chạy nền), `popup.html` / `popup.js` (cửa sổ nhỏ).
