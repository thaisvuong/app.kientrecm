const $ = s => document.querySelector(s);
const SLOT = { me: 'phiên nhận xét của bạn', office: 'phiên giáo vụ (dùng chung)' };
function ago(iso) { const s = Math.round((Date.now() - new Date(iso).getTime()) / 1000); return s < 60 ? 'vừa xong' : s < 3600 ? Math.round(s / 60) + ' phút trước' : s < 86400 ? Math.round(s / 3600) + ' giờ trước' : new Date(iso).toLocaleString('vi-VN'); }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
function paint(st) {
  const el = $('#st');
  if (!st) { el.className = 'st'; el.innerHTML = '<span class="dot"></span><span>Chưa gửi lần nào</span>'; return; }
  el.className = 'st' + (st.ok ? ' ok' : '');
  el.innerHTML = '<span class="dot"></span><span>' + (st.ok ? 'Đã nối <b>' + esc((st.who && (st.who.name || st.who.email)) || '') + '</b>' + (st.who && st.who.role ? ' · ' + esc(st.who.role) : '') + '<small>' + esc(SLOT[st.slot] || '') + ' · gửi ' + ago(st.at) + (st.why ? ' (' + esc(st.why) + ')' : '') + '</small>'
    : esc(st.err || 'Chưa nối') + '<small>' + ago(st.at) + '</small>') + '</span>';
}
chrome.storage.local.get(['code', 'last']).then(o => { $('#code').value = o.code || ''; paint(o.last); });
chrome.storage.onChanged.addListener(ch => { if (ch.last) paint(ch.last.newValue); });
$('#save').onclick = async () => {
  const v = $('#code').value.trim(); $('#save').disabled = true;
  await chrome.storage.local.set({ code: v, sent: '' });
  paint(await chrome.runtime.sendMessage({ saved: 1 })); $('#save').disabled = false;
};
$('#push').onclick = async () => { $('#push').disabled = true; paint(await chrome.runtime.sendMessage({ push: 1 })); $('#push').disabled = false; };
