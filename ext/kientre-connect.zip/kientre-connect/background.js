/* Kiến Trẻ Connect — chạy nền: đọc cookie đăng nhập kientre.click của Chrome (kể cả httpOnly, quyền "cookies")
   và gửi về web Kiến Chuyên môn (ktExtPush, xác thực bằng MÃ KẾT NỐI lấy ở Kiến Trẻ › Kết nối).
   Gửi khi: cài / mở Chrome · phiên đổi (đăng nhập lại, đổi tài khoản) · 6 giờ một lần · bấm “Gửi ngay”.
   Cookie chỉ đi tới đúng link /exec trong mã kết nối, không đi đâu khác. */
const KT_HOST = 'kientre.click', EVERY_MIN = 360;
const VER = chrome.runtime.getManifest().version;

chrome.runtime.onInstalled.addListener(() => { schedule(); push('cài đặt'); });
chrome.runtime.onStartup.addListener(() => { schedule(); push('mở Chrome'); });
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'kt') push('định kỳ', true); });
chrome.cookies.onChanged.addListener(ch => {      // đăng nhập / đăng xuất / làm mới phiên bên kientre.click
  const c = ch.cookie; if (!c || !isKt(c.domain) || !/session-token|csrf|callback-url/i.test(c.name)) return;
  clearTimeout(push.t); push.t = setTimeout(() => push(ch.removed && ch.cause === 'explicit' ? 'đăng xuất' : 'phiên đổi'), 2500);
});
chrome.runtime.onMessage.addListener((m, s, reply) => {
  if (m && m.push) { push('bấm Gửi ngay', true).then(reply); return true; }
  if (m && m.saved) { push('lưu mã', true).then(reply); return true; }
});

function isKt(d) { d = String(d || '').replace(/^\./, ''); return d === KT_HOST || d.endsWith('.' + KT_HOST); }
/** mã kết nối = base64 (url-safe) của { u: link /exec, k: khoá, s: me | office } — u chỉ được là Apps Script (hoặc máy dev localhost): cookie không bao giờ đi tới trang lạ */
function decode(code) {
  try { const j = JSON.parse(atob(String(code || '').trim().replace(/\s+/g, '').replace(/-/g, '+').replace(/_/g, '/'))); return j && j.u && j.k && /^(https:\/\/script\.google(usercontent)?\.com\/|http:\/\/localhost:\d+\/)/.test(j.u) ? j : null; } catch (e) { return null; }
}
function schedule() { chrome.alarms.clear('kt').then(() => chrome.alarms.create('kt', { periodInMinutes: EVERY_MIN, delayInMinutes: 5 })); }
/** dòng cookie của kientre.click như trình duyệt gửi (tên=giá trị; …) — '' nếu chưa đăng nhập */
async function cookieLine() {
  const L = (await chrome.cookies.getAll({ domain: KT_HOST })).filter(c => isKt(c.domain) && (!c.expirationDate || c.expirationDate * 1000 > Date.now()));
  if (!L.some(c => /session-token/i.test(c.name))) return '';
  return L.sort((a, b) => a.name.localeCompare(b.name)).map(c => c.name + '=' + c.value).join('; ');
}
async function hash(s) { const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)); return Array.from(new Uint8Array(b)).slice(0, 12).map(x => x.toString(16).padStart(2, '0')).join(''); }
async function rpc(u, fn, p) {
  const r = await fetch(u, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify({ fn: fn, p: p }), redirect: 'follow' });
  let j; try { j = await r.json(); } catch (e) { throw new Error('Web Kiến Chuyên môn không trả lời đúng (mã ' + r.status + ')'); }
  if (!j.ok) throw new Error(j.error || 'Web Kiến Chuyên môn báo lỗi');
  return j.data;
}
async function save(st) {
  st.at = new Date().toISOString();
  await chrome.storage.local.set({ last: st });
  chrome.action.setBadgeText({ text: st.ok ? '' : '!' });
  chrome.action.setBadgeBackgroundColor({ color: '#B42318' });
  return st;
}
let busy = null;
/** gửi phiên — bỏ qua nếu phiên không đổi và vừa gửi được trong 6 giờ (force = luôn gửi) */
function push(why, force) {
  if (busy) return busy;
  busy = (async () => {
    const o = await chrome.storage.local.get(['code', 'sent', 'last']), c = decode(o.code);
    if (!c) return save({ ok: 0, err: 'Chưa dán mã kết nối — bấm biểu tượng Kiến Trẻ Connect để dán', why: why });
    const ck = await cookieLine(), h = ck ? await hash(ck) : '';
    if (!ck) { await rpc(c.u, 'ktExtPush', { key: c.k, cookie: '', err: 'Chrome chưa đăng nhập kientre.click', ver: VER }).catch(() => {});
      await chrome.storage.local.set({ sent: '' }); return save({ ok: 0, err: 'Chrome chưa đăng nhập kientre.click — đăng nhập rồi tiện ích tự gửi', why: why, slot: c.s }); }
    const S = o.sent || {}, fresh = S.h === h && Date.now() - new Date(S.at || 0).getTime() < EVERY_MIN * 60000;
    if (fresh && !force && o.last && o.last.ok) return o.last;
    const r = await rpc(c.u, 'ktExtPush', { key: c.k, cookie: ck, ver: VER });
    await chrome.storage.local.set({ sent: { h: h, at: new Date().toISOString() } });
    return save({ ok: 1, who: r.who, slot: r.slot, why: why });
  })().catch(e => save({ ok: 0, err: String(e && e.message || e), why: why })).finally(() => { busy = null; });
  return busy;
}
