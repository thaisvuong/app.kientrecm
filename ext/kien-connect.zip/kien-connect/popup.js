const $ = s => document.querySelector(s);
const SLOT = { me: 'phiên nhận xét của bạn', office: 'phiên giáo vụ (dùng chung)' };
function ago(iso) { const s = Math.round((Date.now() - new Date(iso).getTime()) / 1000); return s < 60 ? 'vừa xong' : s < 3600 ? Math.round(s / 60) + ' phút trước' : s < 86400 ? Math.round(s / 3600) + ' giờ trước' : new Date(iso).toLocaleString('vi-VN'); }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
/** (2.0.2) lỗi lưu từ bản cũ (“Failed to fetch”) → câu tiếng Việt */
function nice(err, title) { return /failed to fetch|networkerror|network error|load failed/i.test(String(err || '')) ? 'Không kết nối được ' + title + ' (mạng chập chờn hoặc mất mạng) — tiện ích tự chạy lại lần sau' : err; }
function box(el, title, st, okText, run) {
  if (run && Date.now() - new Date(run).getTime() < 10 * 60000) {      // đang chạy (quá 10 phút coi như Chrome đã dừng giữa chừng)
    el.className = 'st run';
    el.innerHTML = '<span class="dot"></span><span><b class="t">' + title + '</b>Đang đồng bộ…<small>bắt đầu ' + ago(run) + (st && st.at ? ' · lần trước ' + (st.ok ? 'xong' : 'lỗi') + ' ' + ago(st.at) : '') + '</small></span>';
    return;
  }
  if (!st) { el.className = 'st'; el.innerHTML = '<span class="dot"></span><span><b class="t">' + title + '</b>Chưa chạy lần nào</span>'; return; }
  if (st.off) { el.className = 'st off'; el.innerHTML = '<span class="dot"></span><span><b class="t">' + title + '</b>Chưa bật trong mã này<small>' + (title === 'Kiến Gia Sư' ? 'Mã dán vào không kèm Đồng bộ KGS — Quản trị lấy mã mới ở Kiến Trẻ › Kết nối rồi dán lại' : 'Mã dán vào không kèm phần này') + '</small></span>'; return; }
  el.className = 'st' + (st.ok ? ' ok' : '');
  el.innerHTML = '<span class="dot"></span><span><b class="t">' + title + '</b>' + (st.ok ? okText(st) : esc(nice(st.err, title) || 'Lỗi')) + '<small>' + ago(st.at) + (st.why ? ' · ' + esc(st.why) : '') + '</small></span>';
}
let LAST = {}, BUSY = {};
function paint() {
  const L = LAST || {}, B = BUSY || {};
  box($('#stKgs'), 'Kiến Gia Sư', L.kgs, st => { const n = st.n || {}; return 'Đồng bộ xong · ' + (n.cls || 0) + ' lớp · thêm ' + (n.add || 0) + ' buổi · ' + (n.topics || 0) + ' topic' + (n.pushed ? ' · ghi ' + n.pushed + ' buổi sang KGS' : '') + (st.who ? ' · ' + esc(st.who) : ''); }, B.kgs);
  box($('#stKt'), 'Kiến Trẻ · kientre.click', L.kt, st => 'Đã nối <b>' + esc((st.who && (st.who.name || st.who.email)) || '') + '</b>' + (st.who && st.who.role ? ' · ' + esc(st.who.role) : '') + ' · ' + esc(SLOT[st.slot] || ''), B.kt);
}
chrome.storage.local.get(['code', 'last', 'busy']).then(o => { $('#code').value = o.code || ''; LAST = o.last; BUSY = o.busy; paint(); });
chrome.storage.onChanged.addListener(ch => { if (ch.last) LAST = ch.last.newValue; if (ch.busy) BUSY = ch.busy.newValue; if (ch.last || ch.busy) paint(); });
setInterval(paint, 30000);      // “bắt đầu x phút trước” tự cập nhật khi popup mở lâu
$('#save').onclick = async () => {
  $('#save').disabled = true;
  await chrome.storage.local.set({ code: $('#code').value.trim(), sent: '' });
  await chrome.runtime.sendMessage({ saved: 1 }); $('#save').disabled = false;
};
$('#run').onclick = async () => { $('#run').disabled = true; try { await chrome.runtime.sendMessage({ run: 1 }); } finally { $('#run').disabled = false; } };
