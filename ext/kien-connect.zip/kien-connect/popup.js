const $ = s => document.querySelector(s);
const SLOT = { me: 'phiên nhận xét của bạn', office: 'phiên giáo vụ (dùng chung)' };
function ago(iso) { const s = Math.round((Date.now() - new Date(iso).getTime()) / 1000); return s < 60 ? 'vừa xong' : s < 3600 ? Math.round(s / 60) + ' phút trước' : s < 86400 ? Math.round(s / 3600) + ' giờ trước' : new Date(iso).toLocaleString('vi-VN'); }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
function box(el, title, st, okText) {
  if (!st) { el.className = 'st'; el.innerHTML = '<span class="dot"></span><span><b class="t">' + title + '</b>Chưa chạy lần nào</span>'; return; }
  if (st.off) { el.className = 'st off'; el.innerHTML = '<span class="dot"></span><span><b class="t">' + title + '</b>Không dùng<small>Mã kết nối không có phần này</small></span>'; return; }
  el.className = 'st' + (st.ok ? ' ok' : '');
  el.innerHTML = '<span class="dot"></span><span><b class="t">' + title + '</b>' + (st.ok ? okText(st) : esc(st.err || 'Lỗi')) + '<small>' + ago(st.at) + (st.why ? ' · ' + esc(st.why) : '') + '</small></span>';
}
function paint(L) {
  L = L || {};
  box($('#stKgs'), 'Kiến Gia Sư', L.kgs, st => { const n = st.n || {}; return 'Đồng bộ xong · ' + (n.cls || 0) + ' lớp · thêm ' + (n.add || 0) + ' buổi · ' + (n.topics || 0) + ' topic' + (n.pushed ? ' · ghi ' + n.pushed + ' buổi sang KGS' : '') + (st.who ? ' · ' + esc(st.who) : ''); });
  box($('#stKt'), 'Kiến Trẻ · kientre.click', L.kt, st => 'Đã nối <b>' + esc((st.who && (st.who.name || st.who.email)) || '') + '</b>' + (st.who && st.who.role ? ' · ' + esc(st.who.role) : '') + ' · ' + esc(SLOT[st.slot] || ''));
}
chrome.storage.local.get(['code', 'last']).then(o => { $('#code').value = o.code || ''; paint(o.last); });
chrome.storage.onChanged.addListener(ch => { if (ch.last) paint(ch.last.newValue); });
$('#save').onclick = async () => {
  $('#save').disabled = true;
  await chrome.storage.local.set({ code: $('#code').value.trim(), sent: '' });
  await chrome.runtime.sendMessage({ saved: 1 }); $('#save').disabled = false;
};
$('#run').onclick = async () => { $('#run').disabled = true; try { await chrome.runtime.sendMessage({ run: 1 }); } finally { $('#run').disabled = false; } };
