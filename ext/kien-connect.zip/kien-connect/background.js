/* Kiến Connect — MỘT tiện ích, MỘT mã kết nối cho hai việc (gộp KGS Sync + Kiến Trẻ Connect, 1.84.2):
   · KGS: cứ N phút (máy chủ quyết, mặc định 60) hỏi web cần đọc / ghi gì (kgsPlan), đọc + ghi app.kiengiasu.edu.vn bằng phiên của Chrome (collect.js),
     gửi kết quả lên (kgsPush). Phiên nền không dùng được → thử trong tab KGS đang mở.
   · Kiến Trẻ: đọc cookie đăng nhập kientre.click (kể cả httpOnly) → ktExtPush khi cài / mở Chrome / phiên đổi / 6 giờ / bấm Gửi ngay.
   Mã kết nối = base64 { u: link /exec, k: khoá Kiến Trẻ, s: me | office, g: khoá KGS } — mã KGS Sync cũ ({ u, k }) và mã Kiến Trẻ Connect cũ ({ u, k, s }) vẫn dùng được.
   Cookie / dữ liệu chỉ đi tới đúng link Apps Script trong mã. */
importScripts('collect.js');
const KGS_ORIGIN = 'https://app.kiengiasu.edu.vn', KT_HOST = 'kientre.click', KT_EVERY = 360;
const VER = chrome.runtime.getManifest().version;

chrome.runtime.onInstalled.addListener(() => { schedule(); runAll('cài đặt'); });
chrome.runtime.onStartup.addListener(() => { schedule(); runAll('mở Chrome'); });
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'kgs') kgsRun(); if (a.name === 'kt') ktPush('định kỳ', true); });
chrome.cookies.onChanged.addListener(ch => {      // đăng nhập / đăng xuất / làm mới phiên bên kientre.click
  const c = ch.cookie; if (!c || !isKt(c.domain) || !/session-token/i.test(c.name)) return;
  clearTimeout(ktPush.t); ktPush.t = setTimeout(() => ktPush(ch.removed && ch.cause === 'explicit' ? 'đăng xuất' : 'phiên đổi'), 2500);
});
chrome.runtime.onMessage.addListener((m, s, reply) => {
  if (m && m.run) { runAll('bấm Chạy ngay', true).then(reply); return true; }
  if (m && m.saved) { schedule().then(() => runAll('lưu mã', true)).then(reply); return true; }
});

/** mã kết nối → { u, kt: { k, s } | null, kgs: khoá | null } · u chỉ được là Apps Script (hoặc máy dev localhost) */
function decode(code) {
  try {
    const j = JSON.parse(atob(String(code || '').trim().replace(/\s+/g, '').replace(/-/g, '+').replace(/_/g, '/')));
    if (!j || !j.u || !/^(https:\/\/script\.google(usercontent)?\.com\/|http:\/\/localhost:\d+\/)/.test(j.u)) return null;
    const kt = j.k && j.s ? { k: j.k, s: j.s } : null, kgs = j.g || (j.k && !j.s ? j.k : null);      // { u, k } không có s = mã KGS Sync cũ
    return kt || kgs ? { u: j.u, kt: kt, kgs: kgs } : null;
  } catch (e) { return null; }
}
async function schedule() {
  const o = await chrome.storage.local.get(['every', 'code']), c = decode(o.code);
  await chrome.alarms.clear('kgs'); await chrome.alarms.clear('kt');
  if (!c || c.kgs) chrome.alarms.create('kgs', { periodInMinutes: Number(o.every) || 60, delayInMinutes: 1 });
  if (!c || c.kt) chrome.alarms.create('kt', { periodInMinutes: KT_EVERY, delayInMinutes: 5 });
}
async function rpc(u, fn, p) {
  const r = await fetch(u, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify({ fn: fn, p: p }), redirect: 'follow' });
  let j; try { j = await r.json(); } catch (e) { throw new Error('Web Kiến Chuyên môn không trả lời đúng (mã ' + r.status + ')'); }
  if (!j.ok) throw new Error(j.error || 'Web Kiến Chuyên môn báo lỗi');
  return j.data;
}
/** trạng thái từng phần: last.kgs · last.kt — chấm đỏ trên biểu tượng khi một phần đang dùng bị lỗi */
async function save(part, st) {
  st.at = new Date().toISOString();
  const o = await chrome.storage.local.get(['last', 'code']), L = Object.assign({}, o.last || {}), c = decode(o.code);
  L[part] = st; await chrome.storage.local.set({ last: L });
  const bad = !c || (c.kgs && L.kgs && !L.kgs.ok) || (c.kt && L.kt && !L.kt.ok);
  chrome.action.setBadgeText({ text: bad ? '!' : '' });
  chrome.action.setBadgeBackgroundColor({ color: '#B42318' });
  return st;
}
function runAll(why, force) { return Promise.all([kgsRun(), ktPush(why, force)]).then(r => ({ kgs: r[0], kt: r[1] })); }

/* ── KGS (giữ nguyên cách làm của KGS Sync) ── */
async function inTab(plan) {
  const tabs = await chrome.tabs.query({ url: KGS_ORIGIN + '/*' });
  if (!tabs.length) return null;
  const [r] = await chrome.scripting.executeScript({ target: { tabId: tabs[0].id }, world: 'MAIN', func: kgsCollect, args: [plan] });
  return r && r.result;
}
let kgsBusy = null;
function kgsRun() {
  if (kgsBusy) return kgsBusy;
  kgsBusy = (async () => {
    const o = await chrome.storage.local.get(['code', 'every']), c = decode(o.code);
    if (!c) return save('kgs', { ok: 0, err: 'Chưa dán mã kết nối — bấm biểu tượng Kiến Connect để dán' });
    if (!c.kgs) return save('kgs', { ok: 1, off: 1 });      // mã không có phần KGS (không phải quản trị) → bỏ qua
    let plan;
    try { plan = await rpc(c.u, 'kgsPlan', { key: c.kgs }); } catch (e) { return save('kgs', { ok: 0, err: e.message }); }
    if (plan.every && Number(plan.every) !== Number(o.every)) { await chrome.storage.local.set({ every: plan.every }); await schedule(); }
    let R = await kgsCollect(plan);
    if (!R.ok && R.auth) R = (await inTab(plan)) || R;
    if (!R.ok) { await rpc(c.u, 'kgsPush', { key: c.kgs, err: R.err, auth: R.auth }).catch(() => {}); return save('kgs', { ok: 0, err: R.err, auth: R.auth }); }
    const r = await rpc(c.u, 'kgsPush', { key: c.kgs, data: R.data });
    return save('kgs', { ok: 1, n: r.n, who: R.data.who });
  })().catch(e => save('kgs', { ok: 0, err: String(e && e.message || e) })).finally(() => { kgsBusy = null; });
  return kgsBusy;
}

/* ── KIẾN TRẺ: phiên kientre.click ── */
function isKt(d) { d = String(d || '').replace(/^\./, ''); return d === KT_HOST || d.endsWith('.' + KT_HOST); }
async function cookieLine() {
  const L = (await chrome.cookies.getAll({ domain: KT_HOST })).filter(c => isKt(c.domain) && (!c.expirationDate || c.expirationDate * 1000 > Date.now()));
  if (!L.some(c => /session-token/i.test(c.name))) return '';
  return L.sort((a, b) => a.name.localeCompare(b.name)).map(c => c.name + '=' + c.value).join('; ');
}
async function hash(s) { const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)); return Array.from(new Uint8Array(b)).slice(0, 12).map(x => x.toString(16).padStart(2, '0')).join(''); }
let ktBusy = null;
/** gửi phiên — bỏ qua nếu phiên không đổi và vừa gửi được trong 6 giờ (force = luôn gửi) */
function ktPush(why, force) {
  if (ktBusy) return ktBusy;
  ktBusy = (async () => {
    const o = await chrome.storage.local.get(['code', 'sent', 'last']), c = decode(o.code);
    if (!c) return save('kt', { ok: 0, err: 'Chưa dán mã kết nối — bấm biểu tượng Kiến Connect để dán', why: why });
    if (!c.kt) return save('kt', { ok: 1, off: 1 });      // mã KGS cũ — không có phần Kiến Trẻ
    const ck = await cookieLine(), h = ck ? await hash(ck) : '';
    if (!ck) { await rpc(c.u, 'ktExtPush', { key: c.kt.k, cookie: '', err: 'Chrome chưa đăng nhập kientre.click', ver: VER }).catch(() => {});
      await chrome.storage.local.set({ sent: '' }); return save('kt', { ok: 0, err: 'Chrome chưa đăng nhập kientre.click — đăng nhập rồi tiện ích tự gửi', why: why, slot: c.kt.s }); }
    const S = o.sent || {}, fresh = S.h === h && Date.now() - new Date(S.at || 0).getTime() < KT_EVERY * 60000, prev = (o.last || {}).kt;
    if (fresh && !force && prev && prev.ok && !prev.off) return prev;
    const r = await rpc(c.u, 'ktExtPush', { key: c.kt.k, cookie: ck, ver: VER });
    await chrome.storage.local.set({ sent: { h: h, at: new Date().toISOString() } });
    return save('kt', { ok: 1, who: r.who, slot: r.slot, why: why });
  })().catch(e => save('kt', { ok: 0, err: String(e && e.message || e), why: why })).finally(() => { ktBusy = null; });
  return ktBusy;
}
