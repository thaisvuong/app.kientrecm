/* KGS Sync — đọc / ghi dữ liệu app.kiengiasu.edu.vn bằng phiên đăng nhập đang có của trình duyệt.
   Cùng các bước với KgsSync.gs › kgsCollect_ (máy chủ, cách dán phiên) — sửa một bên thì sửa cả bên kia.
   Hàm tự đủ (không dùng biến bên ngoài) để chạy được cả trong service worker lẫn trong trang KGS đang mở (chrome.scripting.executeScript).
   plan (từ kgsPlan) = { codes: mã lớp cần đọc lịch, queue: topic chờ bấm đồng bộ, auto: 1 = đọc danh sách lớp + gia sư để tự thêm lớp,
                         notes: [{ id: mã buổi KGS, text: dòng “Tài liệu khác…” cần có ('' = gỡ), h }],
                         roads: [{ spId, items, appliesFrom, key }] lộ trình đã sắp ở Kiến CM cần lưu bên KGS (1.60),
                         one: [{ spId, id, subject, key, ids, srcs, names, date }] buổi sắp tới nhiều bài → “Đổi bài cho buổi này” (1.71) }
   Không ném lỗi: trả { ok: 1, data } hoặc { ok: 0, err, auth: 1 = phiên hết hạn }. */
async function kgsCollect(plan, queue) {
  if (Array.isArray(plan)) plan = { codes: plan, queue: queue };      // tiện ích bản 1.0 gọi kgsCollect(codes, queue)
  plan = plan || {};
  const API = 'https://app.kiengiasu.edu.vn/api';
  const kcode = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[đĐ]/g, 'd').toLowerCase().replace(/[^a-z0-9]/g, '');
  const fail = (msg, auth) => { const e = new Error(msg); e.auth = auth ? 1 : 0; return e; };
  const FEAT = [['/classes', 'Lớp học'], ['/schedule', 'Thời khóa biểu'], ['/admin/schedules', 'Thời khóa biểu'], ['/admin/staff', 'Nhân sự'], ['/tutor-options', 'Nhân sự'],
    ['/admin/roadmap', 'Lộ trình học'], ['/students', 'Học sinh'], ['/admin/programs', 'Chương trình'], ['/admin/topics', 'Tài liệu giảng dạy'], ['/topics', 'Tài liệu giảng dạy']];
  const perm = (path, method) => { const f = FEAT.filter(x => String(path).indexOf(x[0]) === 0)[0]; return f ? f[1] + ' › ' + (!method || method === 'GET' ? 'Xem' : 'Chỉnh sửa') : ''; };
  const res = async (r, path, method) => {
    if (r.status === 401 || r.redirected) throw fail('Phiên đăng nhập KGS đã hết — mở app.kiengiasu.edu.vn và đăng nhập lại', 1);
    if (r.status === 403) { const p = perm(path, method); throw fail(p ? 'Tài khoản KGS chưa có quyền “' + p + '” (' + String(path).split('?')[0] + ')' : 'Tài khoản KGS không có quyền ở ' + path); }
    if (!r.ok) { let m = ''; try { const j = (await r.json()) || {}; m = (j.error && (j.error.message || (typeof j.error === 'string' ? j.error : ''))) || j.message || ''; } catch (e) {}
      throw fail('KGS trả lỗi ' + r.status + ' ở ' + path + (m ? ': ' + String(m).slice(0, 160) : '')); }
    let j; try { j = await r.json(); } catch (e) { throw fail('KGS không trả dữ liệu ở ' + path + ' (có thể phiên đã hết)', 1); }
    if (j && typeof j === 'object' && j.success === false) throw fail('KGS từ chối ở ' + path + ': ' + String((j.error && (j.error.message || j.error)) || '').slice(0, 160));
    return j && typeof j === 'object' && 'success' in j && 'data' in j ? j.data : j;
  };
  // (1.77.24) Cơ sở học của lớp (KGS › Vận hành › Cơ sở) — giống KgsSync.gs › kgsCampus_
  const CAMPUS_K = ['facility', 'facilityName', 'branch', 'branchName', 'campus', 'campusName', 'center', 'centerName', 'centre', 'location', 'locationName', 'learningLocation', 'studyLocation', 'studyPlace', 'place', 'placeName', 'base', 'baseName', 'site', 'office', 'coSo', 'co_so', 'address'];
  const campusOf = c => { if (!c || typeof c !== 'object') return null;
    for (const k of CAMPUS_K) { let v = c[k]; if (v && typeof v === 'object') v = v.name || v.title || v.label || v.code || ''; if (typeof v === 'string' && v.trim()) return v.trim(); }
    for (const k of Object.keys(c)) { const v = c[k]; if (typeof v === 'string' && v.length < 60 && /tại nhà|tai nha|cơ sở|co so|online|trực tuyến/i.test(v)) return v.trim(); }
    return null; };
  const get = path => fetch(API + path, { credentials: 'include', headers: { Accept: 'application/json' } }).then(r => res(r, path));
  const send = (method, path, body) => fetch(API + path, { method: method, credentials: 'include', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(body || {}) }).then(r => res(r, path, method));
  const post = path => send('POST', path, {});
  const all = async paths => {      // tối đa 6 yêu cầu cùng lúc, giữ thứ tự
    const out = new Array(paths.length); let i = 0;
    await Promise.all(Array.from({ length: Math.min(6, paths.length) }, async () => { while (i < paths.length) { const k = i++; out[k] = await get(paths[k]); } }));
    return out;
  };
  const listOf = j => Array.isArray(j) ? j : (j && (j.items || j.records || j.data)) || [];
  const pages = async (path, size) => {
    const out = [];
    for (let p = 1; p <= 40; p++) {
      const j = (await get(path + (path.indexOf('?') >= 0 ? '&' : '?') + 'page=' + p + '&pageSize=' + size)) || {}, L = listOf(j);
      out.push(...L);
      if (!L.length || !j.totalPages || p >= j.totalPages) break;
    }
    return out;
  };
  try {
    const D = { at: new Date().toISOString(), done: [], fail: [], pushed: [] };
    const me = (await get('/auth/me')) || {}; D.who = String((me.user || me).email || '');
    const want = {}; (plan.codes || []).forEach(c => { want[c] = 1; });
    // LỚP + GIA SƯ (tự thêm lớp GS- đang học bên KGS chưa có ở Kiến Chuyên môn) — lỗi ở đây không làm hỏng phần lịch
    if (plan.auto) {
      try {
        const cls = (await pages('/classes', 500)).filter(c => /^ACTIVE$/i.test(String(c.status || '')) && /^gs/.test(kcode(c.className || c.classCode)));
        let staff = [], opts = [];
        try { staff = await pages('/admin/staff?role=TUTOR', 500); } catch (e) { if (e.auth) throw e; D.fail.push({ kind: 'staff', err: String(e.message || e).slice(0, 200) }); }
        try { opts = listOf(await get('/tutor-options')); } catch (e) { if (e.auth) throw e; }
        D.tutors = staff.map(s => ({ id: s.id, name: s.name || '', email: s.email || '', status: s.status || '' }))
          .concat(opts.filter(o => !staff.some(s => s.id === o.id)).map(o => ({ id: o.id, name: o.name || '', email: o.email || '' })));
        D.clsKeys = Object.keys(cls[0] || {}).slice(0, 80);      // (1.77.24) tên các trường lớp KGS gửi về (dò trường Cơ sở)
        D.classes = cls.map(c => ({ id: c.id, campus: campusOf(c), code: c.className || c.classCode, status: c.status, program: (c.program && (c.program.name || c.program)) || '', programId: String(c.programId || (c.program && c.program.id) || ''), grades: c.grades || [],
          students: (c.students || []).filter(s => !/inactive|left|nghi/i.test(String(s.status || ''))).map(s => s.name || s.studentName || '').filter(Boolean),
          scodes: (c.students || []).filter(s => !/inactive|left|nghi/i.test(String(s.status || ''))).map(s => String(s.studentCode || (s.student && s.student.studentCode) || s.code || '').trim()).filter(Boolean),      // (1.78.2) mã học sinh
          slots: (c.fixedSchedule && c.fixedSchedule.length ? c.fixedSchedule : (c.fixedDays || []).map((d, i) => ({ day: d, timeSlot: (c.fixedTimeSlots || [])[i] || (c.fixedTimeSlots || [])[0] || '' })))
            .map(s => ({ day: s.day || s.dayOfWeek || '', time: s.timeSlot || '', tutorId: s.tutorId || '', subject: s.subject || '' })) }));
        D.classes.forEach(c => { want[kcode(c.code)] = 1; });      // đọc luôn lịch của lớp sắp được thêm
      } catch (e) { if (e.auth) throw e; D.fail.push({ kind: 'classes', err: String(e.message || e).slice(0, 200) }); }
    }
    const tl = (await pages('/admin/roadmap-templates', 100)).filter(t => !/retire/i.test(String(t.status || '')));
    const det = await all(tl.map(t => '/admin/roadmap-templates/' + t.id));
    D.templates = [];
    for (let i = 0; i < tl.length; i++) {
      const t = tl[i], st = await pages('/admin/roadmap-templates/' + t.id + '/students', 200);
      D.templates.push({ id: t.id, name: t.name, topics: ((det[i] || {}).topics || []).map(x => ({ order: x.order, length: x.length, name: x.name, driveFolderId: x.driveFolderId })),
        students: st.map(s => ({ studentCode: (s.student || {}).studentCode, studentName: (s.student || {}).studentName, classNames: s.classNames || [], startTopic: s.startTopic || '' })) });
    }
    const pg = {}; tl.forEach(t => { if (t.program && t.program.id) pg[t.program.id] = t.program.name || ''; });
    const stu = (await pages('/admin/roadmaps', 100)).filter(s => (s.programs || []).some(g => (g.classNames || []).some(cn => want[kcode(cn)])));
    // (1.63) tạo topic giữ chỗ trong kho từng khoá (một thư mục Drive dùng chung, “không xoá”) — đã có topic trỏ đúng thư mục thì dùng lại
    if (plan.holdMake && plan.holdMake.items) {
      D.holdMade = [];
      for (const h of plan.holdMake.items) {
        try {
          const L = listOf(await get('/admin/programs/' + encodeURIComponent(h.pid) + '/topics'));
          const ex = L.filter(t => String(t.driveFolderId || '') === String(plan.holdMake.folderId) && (!h.subj || !t.subject || String(t.subject).toUpperCase() === h.subj))[0];
          const t = ex || (await send('POST', '/admin/programs/' + encodeURIComponent(h.pid) + '/topics', { name: plan.holdMake.name || 'Buổi tự do · giữ chỗ (không xoá)', description: plan.holdMake.desc || null, code: null, grade: null, subject: h.subj || null, driveFolderUrl: plan.holdMake.url })) || {};
          if (t.id) D.holdMade.push({ pid: h.pid, subj: h.subj || '', id: String(t.id) }); else D.fail.push({ kind: 'hold', id: h.pid, err: 'KGS không trả mã topic' });
        } catch (e) { if (e.auth) throw e; D.fail.push({ kind: 'hold', id: h.pid, err: String(e.message || e).slice(0, 200) }); }
      }
    }
    // (1.66.2) đổi tên topic giữ chỗ cũ bên KGS sang tên gia sư đọc được
    for (const h of (plan.holdRename || [])) { try { await send('PATCH', '/admin/topics/' + encodeURIComponent(h.id), { name: h.name, description: h.description }); } catch (e) { if (e.auth) throw e; D.fail.push({ kind: 'hold', id: h.id, err: String(e.message || e).slice(0, 200) }); } }
    // lộ trình sắp ở Kiến CM → lưu bên KGS TRƯỚC (như nút Lưu ở trang lộ trình KGS), rồi mới đọc lại · (1.63) mã lộ trình “mã~MÔN” → gửi kèm môn
    D.roadsDone = [];
    // (1.74) sắp lại bản chờ theo lộ trình MỚI NHẤT của bé — cùng cách với KgsSync.gs › kgsRebase_ (sửa một bên thì sửa cả bên kia)
    const rebase = (items, T, hold) => {
      T = (T || []).map(t => ({ id: String(t.id || ''), src: String(t.sourceTopicId || t.src || ''), len: Math.max(1, Number(t.length || t.len) || 1), status: String(t.status || ''), used: Number(t.consumedSessions || t.used) || 0 }));
      if (!T.length) return items || [];
      const H = String(hold || ''), by = {}, Dn = {}, DS = {}, seen = {}, rest = [];
      T.forEach(t => { by[t.id] = t; if (t.status === 'DONE') { Dn[t.id] = 1; if (t.src && t.src !== H) DS[t.src] = 1; } });
      (items || []).forEach(it => {
        if (!it) return;
        const n = Math.max(1, Math.round(Number(it.length)) || 1), id = String(it.id || '');
        if (id && Dn[id]) { if (H && n > by[id].len) rest.push({ sourceTopicId: H, length: n - by[id].len }); return; }
        if (id && by[id]) { if (seen[id]) return; seen[id] = 1; rest.push({ id: id, sourceTopicId: by[id].src || it.sourceTopicId, length: Math.max(n, by[id].used || 0) }); return; }
        const src = String(it.sourceTopicId || ''); if (!src || DS[src]) return;
        rest.push({ sourceTopicId: src, length: n });
      });
      const prog = T.filter(t => t.status !== 'DONE' && t.used > 0 && !seen[t.id]).map(t => ({ id: t.id, sourceTopicId: t.src, length: Math.max(t.len, t.used) }));
      const out = T.filter(t => t.status === 'DONE').map(t => ({ id: t.id, sourceTopicId: t.src, length: t.len })).concat(prog);
      rest.forEach(o => { const l = out[out.length - 1]; if (!o.id && l && !l.id && l.sourceTopicId === o.sourceTopicId) l.length += o.length; else out.push(o); });
      return out;
    };
    for (let r of (plan.roads || [])) {
      // (1.66) môn chưa có lộ trình bên KGS (create) → POST …/custom như Gán lộ trình › Tự chọn topic
      const sp = String(r.spId).split('~'), p = '/admin/roadmaps/' + encodeURIComponent(sp[0]);
      if (!r.create && !r.re) try { const R = (await get(p + (sp[1] ? '?subject=' + sp[1] : ''))) || {}; if ((R.topics || []).length) r = Object.assign({}, r, { items: rebase(r.items, R.topics, r.hold) }); } catch (e) { if (e.auth) throw e; }
      const body = r.create ? { items: (r.items || []).map(it => ({ sourceTopicId: it.sourceTopicId, length: it.length })), appliesFrom: r.appliesFrom || null } : { items: r.items, appliesFrom: r.appliesFrom || null, detachFromTemplate: true }; if (sp[1]) body.subject = sp[1];
      // (1.80.1) tạo mới mà KGS đã có lộ trình (409 “chọn nối thêm hay thay thế”) → đọc lộ trình hiện có, sắp lại rồi LƯU (…/apply) — như KgsSync.gs › kgsRoadSend_
      const mk = async () => { try { return await send('POST', p + '/custom', body); } catch (e) {
        if (e.auth || !/lỗi 409\b|nối thêm hay thay thế/i.test(String(e.message || e))) throw e;
        const R = (await get(p + (sp[1] ? '?subject=' + sp[1] : ''))) || {}; if (!(R.topics || []).length) throw e;
        const a = { items: rebase(r.items, R.topics, r.hold), appliesFrom: r.appliesFrom || null, detachFromTemplate: true }; if (sp[1]) a.subject = sp[1];
        return send('PATCH', p + '/apply', a); } };
      try { const j = (await (r.create ? mk() : send('PATCH', p + '/apply', body))) || {}; D.roadsDone.push({ spId: r.spId, key: r.key, changes: Number(j.changes) || 0, create: r.create ? 1 : 0 }); }
      catch (e) { if (e.auth) throw e; D.fail.push({ kind: 'road', id: r.spId, err: String(e.message || e).slice(0, 200), create: r.create ? 1 : 0 }); }
    }
    // (1.71) buổi sắp tới có nhiều bài → “Đổi bài cho buổi này” (một buổi nhiều topic): XEM TRƯỚC (dryRun), chỉ lưu thật khi KGS trả đúng các topic đó
    // cho đúng buổi và không bỏ qua topic nào — cùng cách với KgsSync.gs › kgsOneCheck_ / kgsOneRun_
    const oneBad = (j, it) => {
      j = j || {}; const L = Array.isArray(j.taught) ? j.taught : null, nm = x => String(x && typeof x === 'object' ? x.name || x.topicName || x.id || '' : x || '').trim();
      if (!L) return 'KGS không trả danh sách bài của buổi khi xem trước';
      const ids = (it.ids || []).map(String), srcs = (it.srcs || []).map(String), names = (it.names || []).map(x => String(x || '').trim().toLowerCase());
      const at = x => { const o = x && typeof x === 'object' ? x : { name: x }, c = [o.id, o.topicId, o.roadmapTopicId].filter(v => v != null).map(String);
        let i = ids.findIndex(v => v && c.indexOf(v) >= 0); if (i >= 0) return i;
        if (o.sourceTopicId) { i = srcs.indexOf(String(o.sourceTopicId)); if (i >= 0) return i; }
        const n = nm(o).toLowerCase(); return n ? names.indexOf(n) : -1; };
      const got = L.map(at);
      if (got.length !== srcs.length || got.some(i => i < 0) || got.some((i, k) => got.indexOf(i) !== k)) return 'KGS xem trước sẽ dạy “' + L.map(nm).join(' + ') + '” — khác bài ở Kiến CM (' + (it.names || []).join(' + ') + ')';
      const sk = (Array.isArray(j.skipped) ? j.skipped : []).map(nm).filter(Boolean);
      if (sk.length) return 'KGS xem trước sẽ bỏ qua “' + sk.join(', ') + '” (không học nữa) — Kiến CM không tự làm';
      const sd = String(j.studyDate || j.date || (j.session && j.session.studyDate) || (j.schedule && j.schedule.studyDate) || '').slice(0, 10);
      if (/^\d{4}-\d{2}-\d{2}$/.test(sd) && it.date && sd !== it.date) return 'KGS sẽ đổi bài cho buổi ' + sd.split('-').reverse().join('/') + ', không phải buổi ' + it.date.split('-').reverse().join('/');
      return '';
    };
    if ((plan.one || []).length) {
      D.oneDone = [];
      for (const it of plan.one) {
        const p = '/admin/roadmaps/' + encodeURIComponent(it.id || String(it.spId).split('~')[0]) + '/skip-to', b = { topicIds: it.ids, chungBuoi: true }; if (it.subject) b.subject = it.subject;
        try {
          const bad = oneBad(await send('PATCH', p, Object.assign({ dryRun: true }, b)), it);
          if (bad) { D.oneDone.push({ spId: it.spId, key: it.key, ok: 0, err: bad.slice(0, 200) }); continue; }
          await send('PATCH', p, b); D.oneDone.push({ spId: it.spId, key: it.key, ok: 1 });
        } catch (e) { if (e.auth) throw e; D.oneDone.push({ spId: it.spId, key: it.key, ok: 0, err: String(e.message || e).slice(0, 200) }); }
      }
    }
    // (1.63) khoá có khai môn → mỗi môn một lộ trình: chỉ đọc môn đang áp dụng (mặc định Toán) · khoá chưa khai môn → lộ trình cả khoá
    const SJ = Array.isArray(plan.subj) && plan.subj.length ? plan.subj : ['MATH'], LN = [];
    stu.forEach(s => (s.programs || []).forEach(g => { if (!g || !g.id || !(g.classNames || []).some(cn => want[kcode(cn)])) return;
      const ss = (g.subjects || []).map(x => String(x && (x.code || x.subject) || x).toUpperCase()).filter(Boolean);
      if (!ss.length) LN.push({ s: s, g: g, sj: '' }); else ss.filter(x => SJ.indexOf(x) >= 0).forEach(x => LN.push({ s: s, g: g, sj: x })); }));
    try {
      const rd = await all(LN.map(l => '/admin/roadmaps/' + encodeURIComponent(l.g.id) + (l.sj ? '?subject=' + l.sj : '')));
      D.lanes = LN.map((l, i) => { const R = rd[i] || {}, pr = R.program || l.g.program || {};
        return { spId: l.g.id + (l.sj ? '~' + l.sj : ''), subject: l.sj, classNames: l.g.classNames || [], student: l.s.studentName || '', studentCode: l.s.studentCode || '', programId: pr.id || '', program: pr.name || '', appliesFrom: R.appliesFrom || '', perWeek: R.sessionsPerWeek || '',
                 topics: (R.topics || []).map(t => ({ id: t.id, src: t.sourceTopicId || '', code: t.code || '', name: t.name || '', len: t.length, status: t.status || '', used: t.consumedSessions || 0 })) }; });
      D.lanes.forEach(l => { if (l.programId && !(l.programId in pg)) pg[l.programId] = l.program; });
    } catch (e) { if (e.auth) throw e; delete D.lanes; D.fail.push({ kind: 'lane', err: String(e.message || e).slice(0, 200) }); }
    // (1.80.23) ĐỒNG BỘ CẢ KHO + SINH TOPIC TỪ THƯ MỤC MỚI — cùng cách với KgsSync.gs › kgsCluRun_ (sửa một bên thì sửa cả bên kia)
    D.clu = []; D.made = []; D.cluCov = {};
    try {
      const C = plan.clu || {}, skip = {}, sn = {}; (C.skip || []).forEach(f => { skip[String(f)] = 1; }); (C.skipName || []).forEach(x => { sn[kcode(x)] = 1; });
      for (let pid of (C.pids || [])) {
        pid = String(pid); if (D.cluCov[pid]) continue;
        let mem = [pid];
        try { const c = (await get('/admin/programs/' + encodeURIComponent(pid) + '/topics/cluster')) || {}, M = (c.members || []).map(m => String((m && m.id) || '')).filter(Boolean); if (M.length) mem = M; } catch (e) { if (e.auth) throw e; }
        if (mem.indexOf(pid) < 0) mem.push(pid);
        let r;
        try { r = (await send('POST', '/admin/programs/' + encodeURIComponent(pid) + '/topics/sync-cluster', mem.length > 1 ? { programIds: mem } : {})) || {}; }
        catch (e) { if (e.auth) throw e; D.fail.push({ kind: 'clu', id: pid, err: String(e.message || e).slice(0, 200) }); continue; }
        mem.forEach(m => { D.cluCov[m] = 1; });
        const nf = (r.newFolders || []).filter(f => f && f.driveFolderId && !skip[String(f.driveFolderId)] && !sn[kcode(f.name)]);
        const o = { pid: pid, mem: mem, upd: (r.updated || []).length, miss: (r.missing || []).map(x => String((x && x.name) || '')).slice(0, 20), same: Number(r.unchanged) || 0, nf: nf.length };
        D.clu.push(o);
        if (!nf.length) continue;
        if (nf.length > (Number(C.newMax) || 40)) { o.many = 1; continue; }
        const by = {}; nf.forEach(f => { const p = String(f.programId || pid); (by[p] = by[p] || []).push(f); });
        for (const p of Object.keys(by)) { const g = (C.gs || {})[p] || {};
          try { await send('POST', '/admin/programs/' + encodeURIComponent(p) + '/topics/from-folders', { items: by[p].map(f => ({ driveFolderId: String(f.driveFolderId), name: String(f.name || ''), grade: g.grade || null, subject: g.subject || null })) });
            by[p].forEach(f => { skip[String(f.driveFolderId)] = 1; D.made.push({ pid: p, f: String(f.driveFolderId), name: String(f.name || '') }); }); }
          catch (e) { if (e.auth) throw e; D.fail.push({ kind: 'cluNew', id: p, err: String(e.message || e).slice(0, 200) }); } }
      }
    } catch (e) { if (e.auth) throw e; D.fail.push({ kind: 'clu', err: String(e.message || e).slice(0, 200) }); }
    const pids = Object.keys(pg), tp = await all(pids.map(id => '/admin/programs/' + id + '/topics'));
    D.topics = [];
    pids.forEach((id, i) => (Array.isArray(tp[i]) ? tp[i] : []).forEach(t => D.topics.push({ id: t.id, programId: id, programName: pg[id], order: t.order, name: t.name, grade: t.grade, subject: t.subject,
      driveFolderId: t.driveFolderId, fileCount: t.fileCount, syncedAt: t.syncedAt })));
    const sc = await all(stu.map(s => '/students/' + s.id + '/schedule'));
    D.schedules = stu.map((s, i) => ({ studentCode: s.studentCode, items: (((sc[i] || {}).items) || []).map(it => ({ loc: campusOf(it) || "", id: it.id, className: it.className, studyDate: it.studyDate, timeSlot: it.timeSlot,
      lesson: it.lesson, status: it.status, attendanceStatus: it.attendanceStatus, subject: it.subject || '', subject2: it.subject2 || '', tutorId: String(it.tutorId || (it.tutor && it.tutor.id) || (it.teacher && it.teacher.id) || ''), tutorName: String(it.tutorName || (it.tutor && (it.tutor.name || it.tutor.fullName)) || (it.teacher && it.teacher.name) || ''), tutorEmail: String(it.tutorEmail || (it.tutor && it.tutor.email) || '') })) }));
    D.sjv = 1;      // (1.66) có môn của từng buổi
    // topic KGS đang gắn cho từng buổi (từ 14 ngày trước) — Kiến CM đánh dấu khớp / lệch, buổi trống nhận đúng topic
    const since = new Date(Date.now() + 7 * 3600e3 - 14 * 864e5).toISOString().slice(0, 10), sids = [];
    D.schedules.forEach(s => s.items.forEach(it => { if (it.id && String(it.studyDate || '').slice(0, 10) >= since && sids.indexOf(it.id) < 0) sids.push(it.id); }));
    try {
      const ch = []; for (let i = 0; i < sids.length; i += 60) ch.push(sids.slice(i, i + 60));
      const M = {}; (await all(ch.map(L => '/admin/schedules/roadmap-topics?ids=' + L.map(encodeURIComponent).join(',')))).forEach(j => { Object.assign(M, (j && j.schedules) || {}); });
      D.stopics = {};
      Object.keys(M).forEach(k => { const e = M[k] || {}, T = [];
        (e.students || []).forEach(st => (st.topics || []).forEach(t => { const src = t.sourceTopicId || ''; if (!T.some(x => x.src === src && x.name === t.name)) T.push({ src: src, name: t.name || '', code: t.code || '' }); }));
        D.stopics[k] = { t: T, r: e.reason || '' }; });
    } catch (e) { if (e.auth) throw e; delete D.stopics; D.fail.push({ kind: 'stopic', err: String(e.message || e).slice(0, 200) }); }
    const QP = (plan.clu && plan.clu.qp) || {};
    for (const id of (plan.queue || [])) {
      if (D.cluCov[QP[id]]) { D.done.push(id); continue; }      // (1.80.23) kho vừa đồng bộ cả kho
      try { await post('/admin/topics/' + id + '/sync'); D.done.push(id); }
      catch (e) { if (e.auth) throw e; D.fail.push({ id: id, err: String(e.message || e).slice(0, 200) }); }
    }
    // BÀI ĐÃ DUYỆT Ở KIẾN CHUYÊN MÔN → dòng “Tài liệu khác…” trong Lưu ý buổi học bên KGS (giữ nguyên phần ghi chú khác của buổi)
    const ops = plan.notes || [];
    if (ops.length) {
      const cn = {}, by = {};
      D.schedules.forEach(s => s.items.forEach(it => { cn[it.id] = { c: it.className, d: String(it.studyDate || '').slice(0, 10) }; }));
      ops.forEach(o => { const k = cn[o.id]; if (!k || !k.c) { D.fail.push({ kind: 'note', id: o.id, err: 'Không thấy buổi bên KGS' }); return; } (by[k.c] = by[k.c] || []).push(Object.assign({ d: k.d }, o)); });
      // (1.66.4) cùng cách với kgsNoteMerge_: cộng vào sau ghi chú Giáo vụ, chỉ gỡ phần của mình
      const merge = (note, text, old) => { let s = String(note || ''); if (old && s.indexOf(old) >= 0) s = s.split(old).join('');
        s = s.replace(/Tài liệu khác \(Kiến Chuyên môn\):[^\n|]*?(?: — https?:\/\/\S+|(?=\s*\||\n|$))/g, '').replace(/📄 [^\n|]*?(?: — https?:\/\/\S+|(?=\s*\||\n|$))/g, '');
        s = s.replace(/\|\s*\|/g, '|').replace(/\n\s*\n+/g, '\n').replace(/^[\s|]+|[\s|]+$/g, ''); return text ? (s ? s + ' | ' + text : text) : s; };
      for (const c of Object.keys(by)) {
        const O = by[c], ds = O.map(o => o.d).filter(Boolean).sort();
        let recs = [];
        try { recs = listOf(await get('/schedule?class=' + encodeURIComponent(c) + (ds.length ? '&dateFrom=' + ds[0] + '&dateTo=' + ds[ds.length - 1] : '') + '&page=1&pageSize=500')); }
        catch (e) { if (e.auth) throw e; O.forEach(o => D.fail.push({ kind: 'note', id: o.id, err: String(e.message || e).slice(0, 200) })); continue; }
        for (const o of O) {
          const r = recs.find(x => String(x.id) === String(o.id));
          if (!r || !('note' in r)) { D.fail.push({ kind: 'note', id: o.id, err: 'Không đọc được Lưu ý buổi học bên KGS' }); continue; }
          const was = String(r.note == null ? '' : r.note).replace(/^\s+|\s+$/g, ''), now = merge(was, o.text, o.old);
          try { if (now !== was) await send('PUT', '/schedule', { id: r.id, note: now }); D.pushed.push({ id: o.id, h: o.h, t: o.text || '' }); }
          catch (e) { if (e.auth) throw e; D.fail.push({ kind: 'note', id: o.id, err: String(e.message || e).slice(0, 200) }); }
        }
      }
    }
    return { ok: 1, data: D };
  } catch (e) { return { ok: 0, err: String(e && e.message || e), auth: e && e.auth ? 1 : 0 }; }
}
