# Kiến Connect

Một tiện ích Chrome thay cho hai tiện ích cũ là **KGS Sync** và **Kiến Trẻ Connect**. Cả hai việc dùng chung một mã kết nối:

- **Kiến Gia Sư.** Đồng bộ hai chiều app.kiengiasu.edu.vn ⇄ Kiến Chuyên môn: lịch, lộ trình, topic, lớp kèm gia sư; bài đã duyệt được ghi ngược vào Lưu ý buổi học. Cách làm giữ nguyên như KGS Sync (`collect.js`, `kgsPlan` / `kgsPush`). Phần này chỉ chạy khi mã có khoá KGS, tức là mã của **quản trị**.
- **Kiến Trẻ.** Đọc cookie đăng nhập kientre.click của Chrome, kể cả cookie httpOnly, rồi gửi về `ktExtPush`. Tiện ích gửi khi cài, khi mở Chrome, khi phiên đổi, 6 giờ một lần, và khi bấm **Chạy ngay**.

## Mã kết nối

Mã có dạng base64 của `{ u: link /exec, k: khoá Kiến Trẻ, s: me | office, g: khoá KGS }`.

- Lấy mã ở **Kiến Trẻ › Kết nối** hoặc **Kiến CM › Đồng bộ KGS**. Với cùng một người, hai trang hiện cùng một mã.
- Mã KGS Sync cũ (`{ u, k }`) và mã Kiến Trẻ Connect cũ (`{ u, k, s }`) vẫn dán được.
- Cookie và dữ liệu chỉ đi tới đúng link Apps Script ghi trong mã (máy dev cho phép thêm `localhost`).

## Cài đặt

1. Tải `https://kientre-internal.click/ext/kien-connect.zip` rồi giải nén.
2. Mở `chrome://extensions` và bật **Chế độ dành cho nhà phát triển**.
3. Bấm **Tải tiện ích đã giải nén**, chọn thư mục `kien-connect`.
4. Bấm biểu tượng tiện ích, dán mã kết nối, rồi bấm **Lưu mã**.

Nếu đã cài **KGS Sync** hoặc **Kiến Trẻ Connect**, hãy gỡ bản cũ để hai tiện ích không cùng đồng bộ.

## Tệp

- `collect.js`: các bước đọc và ghi KGS. Phải giữ giống `KgsSync.gs › kgsCollect_`; sửa một bên thì sửa cả bên kia.
- `background.js`: hẹn giờ KGS, gửi phiên kientre.click.
- `popup.html` / `popup.js`: dán mã, xem trạng thái hai phần, nút Chạy ngay.
