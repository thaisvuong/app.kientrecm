/* Gemini Bridge — hỏi gemini.google.com bằng phiên đăng nhập của Chrome (không cần khoá API).
   Hàm gemAskWeb phải TỰ ĐỦ (không dùng biến ngoài) vì background.js còn tiêm nguyên hàm này vào tab Gemini
   (chrome.scripting.executeScript, world MAIN) khi gọi từ nền không được.

   Giao thức (giống giao diện web):
   1. GET  /app  → lấy SNlM0e (token "at"), cfb2h (bl), FdrFJe (f.sid) trong HTML. Không có SNlM0e = chưa đăng nhập.
   2. POST /_/BardChatUi/data/assistant.lamda.BardFrontendService/StreamGenerate
      body: at=<SNlM0e>&f.req=[null,"[[prompt],null,[cid,rid,rcid]]"]
   3. Trả về: )]}' rồi các dòng [["wrb.fr",null,"<JSON>"]]; mỗi dòng là ẢNH CHỤP CỘNG DỒN của câu trả lời
      → lấy dòng cuối có chữ. inner[4][0][1] = các đoạn chữ, inner[1] = [cid, rid], inner[4][0][0] = rcid. */
async function gemAskWeb(job) {
  job = job || {};
  const hl = job.hl || 'vi';
  const base = 'https://gemini.google.com' + (Number(job.acct) > 0 ? '/u/' + Number(job.acct) : '');
  try {
    const page = await fetch(base + '/app', { credentials: 'include', cache: 'no-store' });
    const html = await page.text();
    const pick = k => { const m = html.match(new RegExp('"' + k + '":"(.*?)"')); return m ? m[1] : ''; };
    const at = pick('SNlM0e'), bl = pick('cfb2h'), sid = pick('FdrFJe');
    if (!at) return { ok: 0, auth: 1, err: 'Chưa đăng nhập Gemini trên Chrome này (không thấy phiên SNlM0e)' };

    const ctx = Array.isArray(job.ctx) && job.ctx.length ? job.ctx : null;
    const inner = [[String(job.prompt || '')], null, ctx];
    const q = new URLSearchParams({ hl: hl, _reqid: String(100000 + Math.floor(Math.random() * 900000)), rt: 'c' });
    if (bl) q.set('bl', bl);
    if (sid) q.set('f.sid', sid);
    const body = new URLSearchParams({ at: at, 'f.req': JSON.stringify([null, JSON.stringify(inner)]) });
    const r = await fetch(base + '/_/BardChatUi/data/assistant.lamda.BardFrontendService/StreamGenerate?' + q.toString(), {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'X-Same-Domain': '1' },
      body: body.toString()
    });
    const raw = await r.text();
    if (!r.ok) return { ok: 0, http: r.status, auth: r.status === 401 || r.status === 403 ? 1 : 0, err: 'Gemini trả mã ' + r.status };

    let text = '', cid = '', rid = '', rcid = '';
    for (const line0 of raw.split('\n')) {
      const line = line0.trim();
      if (!line || line.indexOf('wrb.fr') < 0) continue;
      let arr;
      try { arr = JSON.parse(line); } catch (e) { continue; }
      if (!Array.isArray(arr)) continue;
      for (const it of arr) {
        if (!Array.isArray(it) || it[0] !== 'wrb.fr' || typeof it[2] !== 'string') continue;
        let d;
        try { d = JSON.parse(it[2]); } catch (e) { continue; }
        const cand = d && d[4] && d[4][0];
        const parts = cand && cand[1];
        if (Array.isArray(parts)) {
          const t = parts.filter(c => typeof c === 'string').join('');
          if (t) {
            text = t;
            if (typeof cand[0] === 'string') rcid = cand[0];
            if (Array.isArray(d[1])) { cid = d[1][0] || cid; rid = d[1][1] || rid; }
          }
        }
      }
    }
    if (!text) return { ok: 0, err: 'Gemini không trả lời (có thể bị giới hạn, bắt xác minh, hoặc Google đổi giao thức)', empty: 1 };
    return { ok: 1, text: text, ctx: [cid, rid, rcid] };
  } catch (e) {
    return { ok: 0, net: 1, err: String((e && e.message) || e) };
  }
}
