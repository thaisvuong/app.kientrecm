const $ = s => document.querySelector(s);
const fmt = iso => { try { return new Date(iso).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' }); } catch (e) { return iso; } };
/** (1.4.0) thẻ trạng thái: chấm màu + dòng chính + dòng phụ · hai ô số (tổng câu, lần trả lời gần nhất) */
function paint(o) {
  const L = o.last, el = $('#st'), set = (cls, t, sub) => { el.className = 'st' + (cls ? ' ' + cls : ''); el.innerHTML = '<span class="dot"></span><span><b></b><small></small></span>'; el.querySelector('b').textContent = t; el.querySelector('small').textContent = sub || ''; };
  if (!L) { set('', 'Chưa chạy lần nào', 'Dán mã kết nối rồi bấm Lưu mã.'); $('#kTot').textContent = '0'; $('#kLast').textContent = '–'; return; }
  const lastAns = L.n ? L.at : L.prevAt;
  if (!L.ok) set('bad', 'Lỗi lúc ' + fmt(L.at), L.err || 'Không rõ lỗi');
  else set(o.hot ? 'hot' : 'ok', o.hot ? 'Chế độ nhanh — hỏi hàng đợi mỗi 2,5 giây' : 'Đang chờ câu hỏi (30 giây / lần)',
    (L.n ? 'Vừa trả lời ' + L.n + ' câu' : lastAns ? 'Sẵn sàng' : 'Chưa có câu hỏi nào') + (L.bad ? ' · lỗi ' + L.bad + ' (' + L.err + ')' : ''));
  $('#kTot').textContent = String(L.total || 0); $('#kLast').textContent = lastAns ? fmt(lastAns) : '–';
}
async function refresh() { paint(await chrome.storage.local.get(['last', 'hot'])); }
/** (1.2.0) khung “Có bản mới”: tải .zip → giải nén ĐÈ vào thư mục đang cài → bấm Tải lại (giữ nguyên mã kết nối, tuỳ chọn) */
function paintUpd(u) {
  const el = $('#upd'); if (!u) { el.style.display = 'none'; return; }
  el.style.display = 'block';
  el.innerHTML = '<b>Có bản mới ' + u.v + ' (đang dùng ' + chrome.runtime.getManifest().version + ')</b>' + (u.notes ? '<div class="mut"></div>' : '') +
    '<ol><li>Tải tệp .zip</li><li>Giải nén, chép ĐÈ vào thư mục đang cài tiện ích (giữ nguyên mã kết nối)</li><li>Bấm “Tải lại tiện ích”</li></ol>' +
    '<div class="row"><a id="dl" target="_blank" rel="noopener">Tải .zip</a><button id="rl">Tải lại tiện ích</button></div>';
  if (u.notes) el.querySelector('.mut').textContent = u.notes;
  el.querySelector('#dl').href = u.zip;
  el.querySelector('#rl').onclick = () => chrome.runtime.sendMessage({ reload: 1 });
}
async function load() {
  const o = await chrome.storage.local.get(['code', 'last', 'hot', 'acct', 'tabOnly', 'noTab', 'hotMin', 'always', 'upd']);
  $('#ver').textContent = chrome.runtime.getManifest().version; paintUpd(o.upd);
  $('#code').value = o.code || '';
  $('#acct').value = o.acct || 0;
  $('#hotMin').value = o.hotMin == null ? 3 : o.hotMin;
  $('#always').checked = !!o.always;
  $('#tabOnly').checked = !!o.tabOnly;
  $('#noTab').checked = !!o.noTab;
  paint(o);
}
chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && (ch.last || ch.hot)) refresh(); if (area === 'local' && ch.upd) paintUpd(ch.upd.newValue); });
$('#save').onclick = async () => {
  await chrome.storage.local.set({ code: $('#code').value.trim() });
  paint({ last: { ok: 1, at: new Date().toISOString(), total: 0 } }); $('#st b').textContent = 'Đã lưu mã — đang kết nối…';
  await chrome.runtime.sendMessage({ saved: 1 });
};
$('#run').onclick = async () => {
  $('#st').className = 'st hot'; const b = $('#st b'); if (b) b.textContent = 'Đang bật chế độ nhanh…';
  await chrome.runtime.sendMessage({ fast: 1 });
};
$('#ask').onclick = async () => {
  const q = $('#q').value.trim(), out = $('#ans');
  if (!q) return;
  $('#ask').disabled = true; out.style.display = 'block'; out.textContent = 'Đang hỏi Gemini…';
  const t0 = Date.now();
  try {
    const R = await chrome.runtime.sendMessage({ ask: q });
    out.textContent = (R && R.ok ? R.text : 'Lỗi: ' + ((R && R.err) || 'không rõ')) + '\n\n— ' + ((Date.now() - t0) / 1000).toFixed(1) + ' giây';
  } finally { $('#ask').disabled = false; }
};
$('#acct').onchange = () => chrome.storage.local.set({ acct: Math.max(0, Number($('#acct').value) || 0) });
$('#hotMin').onchange = () => chrome.storage.local.set({ hotMin: Math.max(0, Math.min(60, Number($('#hotMin').value) || 0)) });
$('#always').onchange = async () => { await chrome.storage.local.set({ always: $('#always').checked }); if ($('#always').checked) chrome.runtime.sendMessage({ fast: 1 }); };
$('#tabOnly').onchange = () => chrome.storage.local.set({ tabOnly: $('#tabOnly').checked });
$('#noTab').onchange = () => chrome.storage.local.set({ noTab: $('#noTab').checked });
$('#chk').onclick = async () => {
  $('#chk').disabled = true; $('#chk').textContent = 'Đang kiểm tra…';
  try { const r = await chrome.runtime.sendMessage({ upd: 1 }); paintUpd(r && r.upd); $('#chk').textContent = r && r.upd ? 'Có bản mới ' + r.upd.v : 'Đang dùng bản mới nhất (' + ((r && r.v) || '') + ')'; }
  finally { $('#chk').disabled = false; }
};
load();

/* (1.3.0) phiên Gemini trên máy chủ */
(async () => {
  const o = await chrome.storage.local.get(['ckOff', 'ckAt', 'ckErr']), ck = document.getElementById('ckOff'), res = document.getElementById('ckRes');
  if (ck) { ck.checked = !!o.ckOff; ck.onchange = () => chrome.storage.local.set({ ckOff: ck.checked ? 1 : 0 }); }
  if (res) res.style.display = 'block';      // (1.5.0) ô kết quả bị .ans ẩn sẵn → trước đây không thấy gì
  if (res) res.textContent = o.ckErr ? 'Lỗi: ' + o.ckErr : o.ckAt ? 'Đã gửi phiên lúc ' + new Date(o.ckAt).toLocaleTimeString('vi-VN') : 'Chưa gửi phiên lần nào';
  const b = document.getElementById('ckNow');
  if (b) b.onclick = () => { b.disabled = true; res.textContent = 'Đang gửi phiên và cho máy chủ hỏi thử Gemini…';      // (1.5.0) gửi + máy chủ hỏi thử luôn
    chrome.runtime.sendMessage({ ck: 1, test: 1 }, r => { b.disabled = false; const T = r && r.test;
      res.textContent = !(r && (r.ok || r.same)) ? 'Chưa gửi được: ' + ((r && r.err) || 'lỗi')
        : T && T.ok ? '✓ Đã gửi phiên — máy chủ hỏi thử Gemini được (' + (T.ms / 1000).toFixed(1) + ' giây: “' + T.text + '”). Tắt Chrome AI vẫn chạy.'
        : T ? '✗ Đã gửi phiên nhưng máy chủ chưa dùng được: ' + T.err + ' — khi Chrome mở, tiện ích vẫn tự trả lời bằng phiên của Chrome.'
        : 'Đã gửi phiên.'; }); };
})();
