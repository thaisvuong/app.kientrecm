const $ = s => document.querySelector(s);
const fmt = iso => { try { return new Date(iso).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' }); } catch (e) { return iso; } };
function paint(o) {
  const L = o.last, el = $('#st');
  if (!L) { el.className = 'st'; el.innerHTML = 'Chưa chạy lần nào.<small>Dán mã kết nối rồi bấm Lưu mã.</small>'; return; }
  el.className = 'st' + (!L.ok ? ' bad' : o.hot ? ' hot' : '');
  el.textContent = !L.ok ? 'Lỗi lúc ' + fmt(L.at)
    : o.hot ? '⚡ Chế độ nhanh — hỏi hàng đợi mỗi 2,5 giây'
    : 'Đang chờ câu hỏi (30 giây / lần)';
  const s = document.createElement('small');
  const lastAns = L.n ? L.at : L.prevAt;
  s.textContent = !L.ok ? L.err
    : (L.n ? 'Vừa trả lời ' + L.n + ' câu lúc ' + fmt(L.at) : lastAns ? 'Trả lời gần nhất lúc ' + fmt(lastAns) : 'Chưa có câu hỏi nào')
      + (L.bad ? ' · lỗi ' + L.bad + ' (' + L.err + ')' : '') + ' · tổng ' + (L.total || 0);
  el.append(s);
}
async function refresh() { paint(await chrome.storage.local.get(['last', 'hot'])); }
/** (1.2.0) khung “Có bản mới”: tải .zip → giải nén ĐÈ vào thư mục đang cài → bấm Tải lại (giữ nguyên mã kết nối, tuỳ chọn) */
function paintUpd(u) {
  const el = $('#upd'); if (!u) { el.style.display = 'none'; return; }
  el.style.display = 'block';
  el.innerHTML = '<b>Có bản mới ' + u.v + ' (đang dùng ' + chrome.runtime.getManifest().version + ')</b>' + (u.notes ? '<div class="mut"></div>' : '') +
    '<ol><li>Tải tệp .zip</li><li>Giải nén, chép ĐÈ vào thư mục đang cài tiện ích (giữ nguyên mã kết nối)</li><li>Bấm “Tải lại tiện ích”</li></ol>' +
    '<div class="row"><a id="dl" target="_blank" rel="noopener">Tải .zip</a><button id="rl">Tải lại tiện ích</button></div>';
  if (u.notes) el.querySelector('.mut').textContent = u.notes;
  el.querySelector('#dl').href = u.zip;
  el.querySelector('#rl').onclick = () => chrome.runtime.sendMessage({ reload: 1 });
}
async function load() {
  const o = await chrome.storage.local.get(['code', 'last', 'hot', 'acct', 'tabOnly', 'noTab', 'hotMin', 'always', 'upd']);
  $('#ver').textContent = chrome.runtime.getManifest().version; paintUpd(o.upd);
  $('#code').value = o.code || '';
  $('#acct').value = o.acct || 0;
  $('#hotMin').value = o.hotMin == null ? 3 : o.hotMin;
  $('#always').checked = !!o.always;
  $('#tabOnly').checked = !!o.tabOnly;
  $('#noTab').checked = !!o.noTab;
  paint(o);
}
chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && (ch.last || ch.hot)) refresh(); if (area === 'local' && ch.upd) paintUpd(ch.upd.newValue); });
$('#save').onclick = async () => {
  await chrome.storage.local.set({ code: $('#code').value.trim() });
  $('#st').className = 'st'; $('#st').textContent = 'Đã lưu mã — đang kết nối…';
  await chrome.runtime.sendMessage({ saved: 1 });
};
$('#run').onclick = async () => {
  $('#st').className = 'st hot'; $('#st').textContent = '⚡ Đang bật chế độ nhanh…';
  await chrome.runtime.sendMessage({ fast: 1 });
};
$('#ask').onclick = async () => {
  const q = $('#q').value.trim(), out = $('#ans');
  if (!q) return;
  $('#ask').disabled = true; out.style.display = 'block'; out.textContent = 'Đang hỏi Gemini…';
  const t0 = Date.now();
  try {
    const R = await chrome.runtime.sendMessage({ ask: q });
    out.textContent = (R && R.ok ? R.text : 'Lỗi: ' + ((R && R.err) || 'không rõ')) + '\n\n— ' + ((Date.now() - t0) / 1000).toFixed(1) + ' giây';
  } finally { $('#ask').disabled = false; }
};
$('#acct').onchange = () => chrome.storage.local.set({ acct: Math.max(0, Number($('#acct').value) || 0) });
$('#hotMin').onchange = () => chrome.storage.local.set({ hotMin: Math.max(0, Math.min(60, Number($('#hotMin').value) || 0)) });
$('#always').onchange = async () => { await chrome.storage.local.set({ always: $('#always').checked }); if ($('#always').checked) chrome.runtime.sendMessage({ fast: 1 }); };
$('#tabOnly').onchange = () => chrome.storage.local.set({ tabOnly: $('#tabOnly').checked });
$('#noTab').onchange = () => chrome.storage.local.set({ noTab: $('#noTab').checked });
$('#chk').onclick = async () => {
  $('#chk').disabled = true; $('#chk').textContent = 'Đang kiểm tra…';
  try { const r = await chrome.runtime.sendMessage({ upd: 1 }); paintUpd(r && r.upd); $('#chk').textContent = r && r.upd ? 'Có bản mới ' + r.upd.v : 'Đang dùng bản mới nhất (' + ((r && r.v) || '') + ')'; }
  finally { $('#chk').disabled = false; }
};
load();
