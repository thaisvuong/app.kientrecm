# Gemini Bridge — tiện ích Chrome cho Trợ lý AI của Kiến Chuyên môn

Cho Trợ lý AI của Kiến Chuyên môn (`src/GeminiWeb.gs`) hỏi **Gemini trên web** bằng **phiên đăng nhập Google đang có trên Chrome** — không cần khoá API, không cần flow qua mail.
Cùng kiểu với **KGS Sync**: tiện ích hỏi web Kiến CM có việc không → làm bằng phiên của trình duyệt → gửi kết quả lên.

- Cứ 30 giây (thời gian ngắn nhất Chrome cho phép) tiện ích hỏi máy chủ `gemPull` có lượt AI nào đang chờ. Vừa trả lời xong thì vào **chế độ nhanh**: hỏi ~2,5 giây / lần thêm 3 phút (biểu tượng ⚡).
- Gửi thân thư (giống hệt thư gửi flow) lên gemini.google.com, đọc câu trả lời, gửi về `gemPush` → máy chủ xử lý ngay (gán bài, yêu cầu, hỏi AI… qua đúng các bước kiểm tra).
- Gọi từ nền không được → chạy trong tab Gemini (tab đang mở, không có thì tự mở một tab ghim chạy ngầm).

## Cài (một lần, trên máy tính)

1. Tải **https://kientre-internal.click/ext/gemini-bridge.zip** (hoặc nút *Tải tiện ích (.zip)* ở **Trợ lý › Cài đặt › Gemini web**), giải nén vào một thư mục cố định — không xoá thư mục này.
2. Chrome **không bị tổ chức chặn tiện ích** (hồ sơ cá nhân) → `chrome://extensions` → bật **Developer mode** → **Load unpacked** → chọn thư mục `gemini-bridge` vừa giải nén.
3. **Trợ lý › Cài đặt › Gemini web (qua tiện ích Chrome)**: bật công tắc, bấm **Chép** mã kết nối.
4. Bấm biểu tượng Gemini Bridge, dán mã, **Lưu mã**. Đăng nhập **gemini.google.com** trên chính Chrome này; thử ở mục *Hỏi thử*.

## Cập nhật (1.2.0)

Chrome không tự cập nhật tiện ích cài kiểu *Load unpacked*, nên tiện ích tự xem `https://kientre-internal.click/ext/gemini-bridge.json` mỗi 6 giờ (nút *Kiểm tra bản mới* để xem ngay).
Có bản mới → biểu tượng hiện **↑**, popup có khung vàng: **Tải .zip** → giải nén, **chép đè** vào thư mục đang cài → **Tải lại tiện ích**. Mã kết nối và tuỳ chọn giữ nguyên.
Tiện ích gửi kèm số bản khi hỏi máy chủ → *Cài đặt › Gemini web* hiện “máy đang kết nối dùng bản … · bản mới nhất …”.
Phát hành bản mới: tăng `version` trong `manifest.json` → `tools/deploy.sh` (hoặc `tools/publish-domain.sh`) tự đóng gói `.zip` + `.json` lên tên miền. Chạy thử thật: `node tools/dev/test_ext.js`.

Chrome phải đang mở thì AI mới trả lời. Biểu tượng có `!` đỏ là đang lỗi (thường do hết phiên Gemini: đăng nhập lại).
Nhiều tài khoản Google trên cùng Chrome: *Tuỳ chọn › Tài khoản Google số* (1 = `/u/1/`).

## Tệp

- `gemini.js`: `gemAskWeb(job)` — lấy token SNlM0e / bl từ trang Gemini, gọi StreamGenerate, đọc câu trả lời. Tự đủ (còn được tiêm vào tab Gemini).
- `background.js`: hẹn giờ, chế độ nhanh, `gemPull` → hỏi → `gemPush`, chuyển sang tab khi gọi từ nền không được.
- `popup.html` / `popup.js`: mã kết nối, trạng thái, hỏi thử, tuỳ chọn.

Bản gốc dùng chung (có cả phía Apps Script độc lập `GeminiBridge.gs`): `~/Claude/Omini/gemini-bridge`. Sửa tiện ích xong bấm ↻ ở thẻ Gemini Bridge trong `chrome://extensions`.
**Lưu ý:** đây là phiên đăng nhập web, không phải API chính thức — Google có thể đổi giao thức hoặc giới hạn tài khoản; nên dùng một tài khoản Google riêng.
