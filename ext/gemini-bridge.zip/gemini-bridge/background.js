/* Gemini Bridge — chạy nền (mẫu theo KGS Sync của Kiến CM):
   cứ 30 giây (chu kỳ ngắn nhất Chrome cho phép) hỏi web Apps Script có câu hỏi nào chờ (gemPull),
   gửi lên gemini.google.com bằng phiên của Chrome (gemini.js), trả câu trả lời về (gemPush).
   Gọi từ nền không được → chạy trong tab Gemini (mở sẵn hoặc tự mở một tab ghim chạy ngầm).

   CHẾ ĐỘ NHANH: vừa trả lời xong một câu thì tiếp tục hỏi hàng đợi mỗi 2,5 giây trong N phút (mặc định 3)
   sau câu cuối, rồi mới quay về chu kỳ 30 giây. "Luôn nhanh" = hỏi mỗi 2,5 giây suốt lúc Chrome mở. */
importScripts('gemini.js');
const GEM_ORIGIN = 'https://gemini.google.com';
const FAST_GAP_MS = 2500;   // khoảng cách giữa hai lần hỏi hàng đợi ở chế độ nhanh
const MAX_JOBS = 500;       // chặn vòng lặp vô tận nếu có lỗi lạ

/* (1.2.0) CẬP NHẬT: tiện ích cài kiểu “Load unpacked” nên Chrome không tự cập nhật — tiện ích tự xem bản mới nhất trên tên miền Kiến CM
   (ext/gemini-bridge.json do tools/publish-domain.sh dựng) mỗi 6 giờ; có bản mới → huy hiệu ↑ + khung “Có bản mới” trong popup (tải .zip, giải nén đè, bấm Tải lại). */
const UPD_URL = 'https://kientre-internal.click/ext/gemini-bridge.json';
const VER = chrome.runtime.getManifest().version;
const newer = (a, b) => { const x = String(a || '').split('.').map(Number), y = String(b || '').split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; };
async function checkUpd(force) {
  const o = await chrome.storage.local.get(['updAt', 'updUrl']);
  if (!force && o.updAt && Date.now() - o.updAt < 6 * 3600000) return (await chrome.storage.local.get(['upd'])).upd || null;
  try {
    const r = await fetch((o.updUrl || UPD_URL) + '?t=' + Date.now(), { cache: 'no-store' }); if (!r.ok) throw new Error('HTTP ' + r.status);
    const j = await r.json(), upd = j && newer(j.v, VER) ? { v: j.v, zip: j.zip, notes: j.notes || '', at: j.at || '' } : null;
    await chrome.storage.local.set({ upd: upd, updAt: Date.now(), updErr: '' }); await badge(); return upd;
  } catch (e) { await chrome.storage.local.set({ updAt: Date.now(), updErr: String(e.message || e) }); return null; }
}
/** huy hiệu lúc rảnh: ↑ xanh dương khi có bản mới */
async function badge() { const o = await chrome.storage.local.get(['upd', 'hot', 'last']); if (o.hot || (o.last && !o.last.ok)) return; chrome.action.setBadgeText({ text: o.upd ? '↑' : '' }); chrome.action.setBadgeBackgroundColor({ color: '#1E4A85' }); }

chrome.runtime.onInstalled.addListener(() => { schedule(); checkUpd(true); });
chrome.runtime.onStartup.addListener(() => { schedule(); run(); checkUpd(); });
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'gem') run(); });
chrome.runtime.onMessage.addListener((m, s, reply) => {
  if (m && m.run) { run({ hot: 1 }); reply({ started: 1 }); return; }
  if (m && m.saved) { schedule().then(() => { run({ hot: 1 }); reply({ started: 1 }); }); return true; }
  if (m && m.fast) { run({ hot: 1 }); reply({ started: 1 }); return; }
  if (m && m.ask) { askOne({ prompt: m.ask }).then(reply); return true; }
  if (m && m.upd) { checkUpd(true).then(u => reply({ upd: u, v: VER })); return true; }
  if (m && m.reload) { reply({ ok: 1 }); setTimeout(() => chrome.runtime.reload(), 100); return; }
});

/** mã kết nối (chạy gbCode() trong Apps Script) = base64 của { u: link /exec của web, k: khoá } */
function decode(code) {
  try { const j = JSON.parse(atob(String(code || '').trim().replace(/-/g, '+').replace(/_/g, '/'))); return j && j.u && j.k ? j : null; } catch (e) { return null; }
}
async function schedule() {
  const o = await chrome.storage.local.get(['every']);
  await chrome.alarms.clear('gem');
  chrome.alarms.create('gem', { periodInMinutes: Math.max(0.5, Number(o.every) || 0.5), delayInMinutes: 0.5 });
}
async function rpc(u, fn, p) {
  const r = await fetch(u, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify({ fn: fn, p: p }), redirect: 'follow' });
  let j; try { j = await r.json(); } catch (e) { throw new Error('Web Apps Script không trả lời đúng (mã ' + r.status + ')'); }
  if (!j.ok) throw new Error(j.error || 'Web Apps Script báo lỗi');
  return j.data;
}
async function save(st) {
  const o = await chrome.storage.local.get(['last']);
  st.at = new Date().toISOString();
  st.total = ((o.last && o.last.total) || 0) + (st.n || 0);
  await chrome.storage.local.set({ last: st });
  return st;
}
/** trạng thái chế độ nhanh: huy hiệu ⚡ xanh khi đang nhanh, ! đỏ khi lỗi */
async function setHot(on, okNow) {
  await chrome.storage.local.set({ hot: on ? 1 : 0 });
  if (okNow === false) { chrome.action.setBadgeText({ text: '!' }); chrome.action.setBadgeBackgroundColor({ color: '#B42318' }); return; }
  if (on) { chrome.action.setBadgeText({ text: '⚡' }); chrome.action.setBadgeBackgroundColor({ color: '#1A7F37' }); return; }
  const u = (await chrome.storage.local.get(['upd'])).upd;
  chrome.action.setBadgeText({ text: u ? '↑' : '' }); chrome.action.setBadgeBackgroundColor({ color: u ? '#1E4A85' : '#1A7F37' });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

/** chờ tab tải xong */
function loaded(tabId) {
  return new Promise(res => {
    const t = setTimeout(() => { chrome.tabs.onUpdated.removeListener(f); res(); }, 20000);
    function f(id, info) { if (id === tabId && info.status === 'complete') { clearTimeout(t); chrome.tabs.onUpdated.removeListener(f); res(); } }
    chrome.tabs.onUpdated.addListener(f);
  });
}
async function gemTab() {
  const tabs = await chrome.tabs.query({ url: GEM_ORIGIN + '/*' });
  if (tabs.length) return tabs[0];
  const o = await chrome.storage.local.get(['noTab']);
  if (o.noTab) return null;
  const t = await chrome.tabs.create({ url: GEM_ORIGIN + '/app', active: false, pinned: true });
  await loaded(t.id);
  return t;
}
async function inTab(job) {
  const tab = await gemTab();
  if (!tab) return null;
  const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: gemAskWeb, args: [job] });
  return r && r.result;
}
/** hỏi một câu: thử từ nền trước, không được thì chạy trong tab Gemini (cùng nguồn gốc, chắc chắn kèm cookie).
    Đã có một lần gọi từ nền thất bại thì các câu sau đi thẳng vào tab (đỡ mất thời gian thử lại). */
let bgFailed = false;
async function askOne(job) {
  const o = await chrome.storage.local.get(['acct', 'tabOnly']);
  if (job.acct == null && o.acct) job.acct = o.acct;
  const viaTab = o.tabOnly || bgFailed;
  let R = viaTab ? { ok: 0 } : await gemAskWeb(job);
  if (!R.ok && (viaTab || R.auth || R.net || R.http || R.empty)) {
    const T = await inTab(job).catch(e => ({ ok: 0, err: String(e.message || e) }));
    if (T && T.ok && !viaTab) bgFailed = true;
    R = T || R;
  }
  if (!R.ok && !R.err) R.err = 'Không mở được tab Gemini';
  return R;
}

let busy = null, hotUntil = 0;
function run(opt) {
  if (opt && opt.hot) hotUntil = Math.max(hotUntil, Date.now() + 60000); // bấm tay / vừa lưu mã: nhanh ít nhất 1 phút
  if (busy) return busy;
  busy = (async () => {
    const o = await chrome.storage.local.get(['code', 'every', 'hotMin']), c = decode(o.code);
    if (!c) { await setHot(false, false); return save({ ok: 0, err: 'Chưa dán mã kết nối — bấm biểu tượng Gemini Bridge để dán' }); }
    const hotMs = (o.hotMin == null ? 3 : Math.max(0, Number(o.hotMin) || 0)) * 60000;
    let n = 0, bad = 0, lastErr = '', first = true, jobs = 0;
    // gọi API của tiện ích định kỳ để Chrome không dừng service worker khi đang chờ Gemini trả lời lâu
    const keep = setInterval(() => { try { chrome.runtime.getPlatformInfo(() => {}); } catch (e) { /* bỏ qua */ } }, 20000);
    try {
      while (jobs < MAX_JOBS) {
        let plan;
        try { plan = await rpc(c.u, 'gemPull', { key: c.k, max: 1, v: VER }); }      // v: máy chủ biết bản tiện ích đang dùng (hiện ở Cài đặt)
        catch (e) { await setHot(false, false); return save({ ok: 0, n: n, err: e.message }); }
        if (first) {
          first = false;
          if (plan.every && Number(plan.every) !== Number(o.every)) { await chrome.storage.local.set({ every: plan.every }); await schedule(); }
        }
        const list = plan.jobs || [];
        if (list.length) {
          if (hotMs > 0) await setHot(true);
          for (const job of list) {
            jobs++;
            const R = await askOne(job);
            if (R.ok) n++; else { bad++; lastErr = R.err; }
            await rpc(c.u, 'gemPush', R.ok ? { key: c.k, id: job.id, text: R.text, ctx: R.ctx } : { key: c.k, id: job.id, err: R.err, auth: R.auth ? 1 : 0 }).catch(() => {});
          }
          await save(bad && !n ? { ok: 0, n: n, bad: bad, err: lastErr } : { ok: 1, n: n, bad: bad, err: lastErr });
          n = 0; bad = 0;
          if (hotMs > 0) hotUntil = Math.max(hotUntil, Date.now() + hotMs);
          continue;
        }
        const s = await chrome.storage.local.get(['always']); // cũng giữ service worker sống
        if (!s.always && Date.now() >= hotUntil) break;
        if (!(await chrome.storage.local.get(['hot'])).hot) await setHot(true);
        await sleep(FAST_GAP_MS);
      }
      await setHot(false); checkUpd();
      const L = (await chrome.storage.local.get(['last'])).last;
      return save({ ok: 1, n: 0, idle: 1, prevAt: L && L.ok && L.n ? L.at : (L && L.prevAt) || '' });
    } finally { clearInterval(keep); }
  })().catch(async e => { await setHot(false, false); return save({ ok: 0, err: String((e && e.message) || e) }); })
     .finally(() => { busy = null; });
  return busy;
}
